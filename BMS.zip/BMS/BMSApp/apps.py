from django.apps import AppConfig


class BmsappConfig(AppConfig):
    name = 'BMSApp'
